#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>

#define PORT 8000
#define MAX_CLIENTS 10

int client_sockets[MAX_CLIENTS];
int client_count = 0;
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

void cleanup(int signum) {
    printf("Server is shutting down...\n");
    for (int i = 0; i < client_count; i++) {
        close(client_sockets[i]);
    }
    exit(0);
}

// Handle communication with a client
void *handle_client(void *arg) {
    int socket = *(int *)arg;
    char buffer[1024];

    while (1) {
        memset(buffer, 0, sizeof(buffer));
        int read_size = recv(socket, buffer, sizeof(buffer) - 1, 0);
        if (read_size <= 0) {
            printf("Client %d disconnected.\n", socket);
            close(socket);

            pthread_mutex_lock(&lock);
            for (int i = 0; i < client_count; i++) {
                if (client_sockets[i] == socket) {
                    client_sockets[i] = client_sockets[client_count - 1];
                    client_count--;
                    break;
                }
            }
            pthread_mutex_unlock(&lock);

            return NULL;
        }

        printf("Received from client %d: %s\n", socket, buffer);

        // Send acknowledgment
        const char *ack_message = "Message received by server.";
        send(socket, ack_message, strlen(ack_message), 0);
    }
}

// Handle server input for broadcasting messages
void *handle_server_input(void *arg) {
    char message[1024];
    while (1) {
        printf("Server: ");
        fgets(message, sizeof(message), stdin);

        pthread_mutex_lock(&lock);
        for (int i = 0; i < client_count; i++) {
            // Check if client is still connected before sending the message
            if (send(client_sockets[i], message, strlen(message), 0) == -1) {
                printf("Error sending message to client %d\n", client_sockets[i]);
            }
        }
        pthread_mutex_unlock(&lock);
    }

    return NULL;
}

int main() {
    signal(SIGINT, cleanup); // Handle SIGINT to gracefully shut down the server

    int server_fd, new_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, 3) < 0) {
        perror("Listen failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    printf("Server is listening on port %d...\n", PORT);

    pthread_t input_thread;
    pthread_create(&input_thread, NULL, handle_server_input, NULL);

    while (1) {
        new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen);
        if (new_socket < 0) {
            perror("Accept failed");
            continue;
        }

        pthread_mutex_lock(&lock);
        if (client_count < MAX_CLIENTS) {
            client_sockets[client_count++] = new_socket;
            printf("New client connected: %d\n", new_socket);

            pthread_t tid;
            pthread_create(&tid, NULL, handle_client, (void *)&new_socket);
        } else {
            printf("Max clients reached. Connection refused.\n");
            close(new_socket);
        }
        pthread_mutex_unlock(&lock);
    }

    close(server_fd);
    return 0;
}

