#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#define SERVER_IP "server"   // Docker service name for the server
#define SERVER_PORT 8000

int main() {
    int sock;
    struct sockaddr_in server;
    char message[1024], server_reply[1024];

    // Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) {
        printf("Could not create socket\n");
        return 1;
    }

    // Set up server address struct
    server.sin_family = AF_INET;
    server.sin_port = htons(SERVER_PORT);
    server.sin_addr.s_addr = inet_addr("172.18.0.2"); // Use internal Docker network IP

    // Connect to server
    if (connect(sock, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("Connection failed");
        return 1;
    }

    printf("Connected to server!\n");

    while (1) {
        // Get input from user
        printf("Enter message: ");
        fgets(message, sizeof(message), stdin);

        // Send message to server
        send(sock, message, strlen(message), 0);

        // Receive reply from server
        memset(server_reply, 0, sizeof(server_reply));
        recv(sock, server_reply, sizeof(server_reply) - 1, 0);

        printf("Server: %s\n", server_reply);
    }

    // Close the socket
    close(sock);
    return 0;
}

